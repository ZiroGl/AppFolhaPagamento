package com.example.appfolhap;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.EmptyStackException;

public class MainActivity extends AppCompatActivity {
    EditText edtNome_main,edtDec_main,edtFilho_main;
    RadioGroup rg;
    RadioButton rgF,rgM;
    Button btnCalcular_main;
    AlertDialog alerta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtNome_main = findViewById(R.id.edtNome_main);
        edtDec_main = findViewById(R.id.edtDec_main);
        edtFilho_main = findViewById(R.id.edtFilho_main);
        rg = findViewById(R.id.rg);
        rgF = findViewById(R.id.rgF);
        rgM = findViewById(R.id.rgM);
        btnCalcular_main = findViewById(R.id.btnCalcular_main);
        btnCalcular_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    //Atributos
                    String n;
                    double s,f,inss=0,ir=0,sf=0,resultado;
                    s = Double.parseDouble(edtDec_main.getText().toString());
                    f = Double.parseDouble(edtFilho_main.getText().toString());
                    n = edtNome_main.getText().toString();
                    //Calculos INSS
                    if(s <= 1212){
                        inss = ((s*7.5)/100);
                    }else if(s == 1212.01 && s <=2427.35){
                        inss = ((s*9)/100);
                    }else if(s == 2427.36 && s <= 3641.03){
                        inss = ((s*12)/100);
                    }else if(s == 3641.04 && s <= 7087.22){
                        inss = ((s*14)/100);
                    }
                    //Calculos IR
                    if(s <= 1903.98){
                        ir = 0;
                    }else if(s == 1903.99 && s <= 2826.65){
                        ir = ((s*7.5)/100);
                    }else if(s == 2826.66 && s <= 3751.05){
                        ir = ((s*15)/100);
                    }else if (s == 3751.06 && s <= 4664.68){
                        ir = ((s*22.5)/100);
                    }
                    //Sálario famili   12){
                        sf = (f*56.47);
                    resultado = s-(inss+ir)+sf;

                    //sexo
                    int op = rg.getCheckedRadioButtonId();
                    if (op == R.id.rgM){
                        Toast.makeText(MainActivity.this, "Sr."+n+" Seu salário liquido é: R$"+resultado+
                            " Foram descontados o valor do INSS E IR respectivamente: R$"+inss+"GF R$"+ir+
                                " O sálario familia é de: R$"+sf, Toast.LENGTH_LONG).show();
                    } else if (op == R.id.rgF) {
                        Toast.makeText(MainActivity.this, "Sra."+n+" Seu salário liquido é: R$"+resultado+
                                " Foram descontados o valor do INSS E IR respectivamente: R$"+inss+"GF R$"+ir+
                                " O sálario familia é de: R$"+sf, Toast.LENGTH_LONG).show();
                    }

                }catch (EmptyStackException e){

                }catch (NumberFormatException a){}



                }

        });

        };




    }
